# ------------------------Модули
import math as mt

# ------------------------Функция
def divide(first, second):
    if second == 0:
        return mt.inf
    return first / second