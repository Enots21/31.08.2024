# ------------------------Модули
from fake_math import divide as fm
from true_math import divide as tm
# ------------------------Результат
result1 = fm(69, 3)
result2 = fm(3, 0)
result3 = tm(49, 7)
result4 = tm(15, 0)
print(result1)
print(result2)
print(result3)
print(result4)
